const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express(); // create express app
const PORT = 3000;

let recipes = require("./public/recipes.json");

// add middlewares
app.use(express.static(path.join(__dirname, "..", "build")));
app.use(express.static("public"));

app.use(bodyParser.json());

app.get("/api/recipes", (req, res) => {
  res.json(recipes);
});

// Middleware to validate JSON content type
const validateJsonContentType = (req, res, next) => {
  if (req.is("json")) {
    return next();
  } else {
    return res
      .status(400)
      .json({ error: "Invalid content type. Please provide JSON data." });
  }
};

app.post("/api/recipes", validateJsonContentType, (req, res) => {
  const newRecipe = req.body;
  // Validate that the request body is a JSON object
  if (typeof newRecipe !== "object" || newRecipe === null) {
    return res.status(400).json({
      error: "Invalid JSON data. Please provide a valid JSON object.",
    });
  }
  newRecipe.id = recipes.length + 1;
  recipes.push(newRecipe);
  return res.status(201).json(newRecipe);
});

// Route handler to retrieve food data from USDA FoodData Central API
app.get("/api/food-data", async (req, res) => {
  const query = req.query.query; // Get the query parameter from the request
  const apiKey = "BNYRgcaCn5LZAbNNbYsXSq5tYK0YfYIMDUYSrCRb"; // Replace 'YOUR_API_KEY' with your actual API key

  // Make API request to USDA FoodData Central API
  try {
    const response = await fetch(
      `https://api.nal.usda.gov/fdc/v1/foods/search?query=${query}&dataType=Foundation&api_key=${apiKey}`
    );
    const data = await response.json();
    console.log(data);
    res.json(data);
  } catch (error) {
    console.error("Error fetching food data:", error);
    res.status(500).json({ error: "Failed to fetch food data" });
  }
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "..", "build", "index.html"));
});

// start express server on port 5000
app.listen(PORT, () => {
  console.log(`server started on port ${PORT}`);
});
