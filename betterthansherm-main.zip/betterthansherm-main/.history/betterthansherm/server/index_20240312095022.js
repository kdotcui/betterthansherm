const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express(); // create express app
const PORT = 5000;

let recipes = require("./public/recipes.json");

// add middlewares
app.use(express.static(path.join(__dirname, "..", "build")));
app.use(express.static("public"));

app.use(bodyParser.json());

app.get("/api/recipes", (req, res) => {
  res.json(recipes);
});

// Middleware to validate JSON content type
const validateJsonContentType = (req, res, next) => {
  if (req.is("json")) {
    return next();
  } else {
    return res
      .status(400)
      .json({ error: "Invalid content type. Please provide JSON data." });
  }
};

app.post("/api/recipes", validateJsonContentType, (req, res) => {
  const newRecipe = req.body;
  // Validate that the request body is a JSON object
  if (typeof newRecipe !== "object" || newRecipe === null) {
    return res.status(400).json({
      error: "Invalid JSON data. Please provide a valid JSON object.",
    });
  }
  newRecipe.id = recipes.length + 1;
  recipes.push(newRecipe);
  return res.status(201).json(newRecipe);
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "..", "build", "index.html"));
});

// start express server on port 5000
app.listen(PORT, () => {
  console.log("server started on port 5000");
});
