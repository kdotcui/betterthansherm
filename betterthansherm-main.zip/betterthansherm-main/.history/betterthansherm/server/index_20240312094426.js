const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express(); // create express app

let recipes = require("./public/recipes.json");

// add middlewares
app.use(express.static(path.join(__dirname, "..", "build")));
app.use(express.static("public"));

app.use(bodyParser.json());

app.get("/api/recipes", (req, res) => {
  res.json(recipes);
});

app.post("/api/recipes", (req, res) => {
  const newRecipe = req.body;
  newRecipe.id = recipes.length + 1;
  recipes.push(newRecipe);
  res.json(newRecipe);

  // Update recipes.json file
  fs.writeFile(
    "./public/recipes.json",
    JSON.stringify(recipes, null, 2),
    (err) => {
      if (err) {
        console.error("Error writing to recipes.json:", err);
        res.status(500).json({ error: "Internal Server Error" });
      } else {
        res.json(newRecipe);
      }
    }
  );
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "..", "build", "index.html"));
});

// start express server on port 5000
app.listen(5000, () => {
  console.log("server started on port 5000");
});
