const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express(); // create express app
const PORT = 3000;

const { CosmosClient } = require("@azure/cosmos");

const cosmosSecrect =
  "AccountEndpoint=https://groupl.documents.azure.com:443/;AccountKey=8IFURqX1k216LdokHXPpt2wv7y73pHFzWYvqi0lXZIMgQHkLU8FfrNPEXxWPVlvvMUkiXH2rriNXACDbiGrIMA==;";
const cosmosClient = new CosmosClient(cosmosSecrect);

const databaseName = "recipes";
const containerName = "recipeList";
const partitionKeyPath = ["/name"];

//inserting data
// const fileAndPathToJson = "items.json";
// const items = JSON.parse(
//   await fs.readFile(path.join(__direname, fileAndPathToJason), "utf-8")
// );

console.log(`\n\ncontainerName: ${containerName}`);
//let recipes = require("./public/recipes.json");

// add middlewares
app.use(express.static(path.join(__dirname, "..", "build")));
app.use(express.static("public"));

app.use(bodyParser.json());

app.get("/api/recipes", async (req, res) => {
  const { database } = await cosmosClient.databases.createIfNotExists({
    id: databaseName,
  });

  const { container } = await database.containers.createIfNotExists({
    id: containerName,
    partitionKey: {
      paths: partitionKeyPath,
    },
  });

  const querySpec = {
    query: `select * from c order by c.id asc`,
    parameters: undefined,
  };
  const { resources } = await container.items.query(querySpec).fetchAll();
  console.log(resources);

  //res.json(recipes);
});

// Middleware to validate JSON content type
const validateJsonContentType = (req, res, next) => {
  if (req.is("json")) {
    return next();
  } else {
    return res
      .status(400)
      .json({ error: "Invalid content type. Please provide JSON data." });
  }
};

app.post("/api/recipes", validateJsonContentType, (req, res) => {
  const newRecipe = req.body;
  // Validate that the request body is a JSON object
  if (typeof newRecipe !== "object" || newRecipe === null) {
    return res.status(400).json({
      error: "Invalid JSON data. Please provide a valid JSON object.",
    });
  }
  newRecipe.id = recipes.length + 1;
  recipes.push(newRecipe);
  return res.status(201).json(newRecipe);
});

// Route handler to retrieve food data from USDA FoodData Central API
app.get("/api/food-data", async (req, res) => {
  const query = req.query.query; // Get the query parameter from the request
  const apiKey = process.env.FOOD_DATA_API_KEY;

  // Make API request to USDA FoodData Central API
  try {
    const response = await fetch(
      `https://api.nal.usda.gov/fdc/v1/foods/search?query=${query}&dataType=Foundation&api_key=${apiKey}`
    );
    const data = await response.json();
    console.log(data);
    res.json(data);
  } catch (error) {
    console.error("Error fetching food data:", error);
    res.status(500).json({ error: "Failed to fetch food data" });
  }
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "..", "build", "index.html"));
});

// start express server on port 5000
app.listen(PORT, () => {
  console.log(`server started on port ${PORT}`);
});
