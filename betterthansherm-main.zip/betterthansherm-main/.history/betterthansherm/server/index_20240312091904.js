const path = require("path");
const express = require("express");
const bodyParser = require("body-parser");
const app = express(); // create express app

let recipes = require("./public/recipes.json");

// add middlewares
app.use(express.static(path.join(__dirname, "..", "build")));
app.use(express.static("public"));

app.use(bodyParser.json());

app.get("/api/recipes", (req, res) => {
  res.json(recipes);
});

app.get("/api/recipes", (req, res) => {
  const newRecipe = req.body;
  newRecipe.id = recipes.length + 1;
  recipes.push(newRecipe);
  res.json(newRecipe);
});

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "..", "build", "index.html"));
});

// start express server on port 5000
app.listen(5000, () => {
  console.log("server started on port 5000");
});
