import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
function Header() {
  return (
    <div className="Header">
      <h1>Better Than Sherm</h1>
    </div>
  );
}

function Footer() {
  return (
    <div className="Footer">
      <h1>Copyright @ 2024 Better than Sherm</h1>
    </div>
  );
}

function Body() {
  return (
    <div className="Body">
      <Recipes />
    </div>
  );
}

function Recipes() {
  let recipes = [];

  return (
    <div className="Recipes">
      <h1>Recipes</h1>
    </div>
  );
}

export default function Homepage() {
  return (
    <div className="Recipes">
      <Header />
      <Body />
      <Footer />
    </div>
  );
}
