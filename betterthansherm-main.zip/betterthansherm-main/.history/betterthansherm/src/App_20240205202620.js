import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import Home from "./components/Home";
import Recipe1 from "./components/recipes/Recipe1";
import Recipd2 from "./components/recipes/Recipe2";
import Recipe3 from "./components/recipes/Recipe3";
import Recipe4 from "./components/recipes/Recipe4";
import Recipe5 from "./components/recipes/Recipe5";
import Recipe6 from "./components/recipes/Recipe6";
import Recipe7 from "./components/recipes/Recipe7";
import { Routes, Route } from "react-router-dom";
/**
 * renders the homepage component.
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Recipe1" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/recipes" element={<Recipes />} />
        <Route path="/recipe/:id" element={<Recipe />} />
      </Routes>
    </div>
  );
}

export default App;
