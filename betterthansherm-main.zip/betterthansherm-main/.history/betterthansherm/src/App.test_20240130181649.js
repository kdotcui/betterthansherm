import React from "react";
import { render } from "@testing-library/react";
import Header from "./App";
import Footer from "./App";
import Body from "./App";
import Recipes from "./App";

describe("Header component", () => {
  test("renders header text", () => {
    const { getByText } = render(<Header />);
    const headerText = getByText("BETTER THAN SHERMAN");
    expect(headerText).toBeInTheDocument();
  });
});

describe("Footer component", () => {
  test("renders footer text", () => {
    const { getByText } = render(<Footer />);
    const footerText = getByText("Better Than Sherm");
    expect(footerText).toBeInTheDocument();
  });
});

describe("Body component", () => {
  test("renders body text", () => {
    const { getByText } = render(<Body />);
    const bodyText = getByText("Recipes");
    expect(bodyText).toBeInTheDocument();
  });
});

describe("Recipes component", () => {
  test("renders recipe items", () => {
    const { getByText } = render(<Recipes />);
    const recipe1 = getByText("Recipe #1");
    const recipe2 = getByText("Speedy Singapore Noodles");
    const recipe3 = getByText("Pork, pepper and rice noodle soup");
    const recipe4 = getByText("Pan-Seared Salmon with Kale and Apple Salad");
    const recipe5 = getByText("Saag paneer");
    const recipe6 = getByText(
      "Sesame-crusted tuna with green tea noodle salad"
    );
    const recipe7 = getByText("Recipe #7");

    expect(recipe1).toBeInTheDocument();
    expect(recipe2).toBeInTheDocument();
    expect(recipe3).toBeInTheDocument();
    expect(recipe4).toBeInTheDocument();
    expect(recipe5).toBeInTheDocument();
    expect(recipe6).toBeInTheDocument();
    expect(recipe7).toBeInTheDocument();
  });
});
