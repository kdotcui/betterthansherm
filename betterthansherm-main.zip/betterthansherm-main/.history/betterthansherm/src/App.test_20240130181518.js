import { render, screen } from "@testing-library/react";
import App from "./App";

it("renders the App component", () => {
  render(<App />);
  const appElement = screen.getByTestId("app");
  expect(appElement).toBeInTheDocument();
});
it("renders the Header component", () => {
  render(<App />);
  const headerElement = screen.getByTestId("header");
  expect(headerElement).toBeInTheDocument();
});

it("renders the Footer component", () => {
  render(<App />);
  const footerElement = screen.getByTestId("footer");
  expect(footerElement).toBeInTheDocument();
});

it("renders the Body component", () => {
  render(<App />);
  const bodyElement = screen.getByTestId("body");
  expect(bodyElement).toBeInTheDocument();
});

it("renders the Recipes component", () => {
  render(<App />);
  const recipesElement = screen.getByTestId("recipes");
  expect(recipesElement).toBeInTheDocument();
});
