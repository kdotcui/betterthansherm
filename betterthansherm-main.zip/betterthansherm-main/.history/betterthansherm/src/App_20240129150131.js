import logo from "./logo.svg";
import "./App.css";

function Recipes() {
  return (
    <div className="Recipes">
      <h1>Recipes</h1>
    </div>
  );
}

export default Recipes;
