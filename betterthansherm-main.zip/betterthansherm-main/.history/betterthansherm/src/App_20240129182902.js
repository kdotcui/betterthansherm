import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Accordion from "react-bootstrap/Accordion";
import Recipe1 from "./recipe1.png";
import Recipe2 from "./recipe2.png";
import Recipe3 from "./recipe3.png";
import Recipe4 from "./recipe4.png";
import Recipe5 from "./recipe5.png";

function Header() {
  return (
    <div className="Header">
      <h1>Better Than Sherm</h1>
    </div>
  );
}

function Footer() {
  return (
    <div className="Footer">
      <p>Copyright @ 2024 Better than Sherm</p>
    </div>
  );
}

function Body() {
  return (
    <div className="Body">
      <h1>Recipes</h1>
      <Recipes />
    </div>
  );
}

function Recipes() {
  return (
    <div className="Recipes">
      <Accordion defaultActiveKey="0">
        <Accordion.Item eventKey="0">
          <Accordion.Header>Recipe #1</Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe1} alt="recipe1" />
                <p>
                  Ingredients:
                  <ul>
                    <li>
                      6 ounces fully-cooked chorizo, casings removed, chopped
                    </li>
                    <li>1 red bell pepper, finely chopped</li>
                    <li>1 small onion, thinly sliced</li>
                    <li>2 cups long-grain rice</li>
                  </ul>
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Whisk the olive oil, sherry, paprika, garlic, 1/2 teaspoon
                  salt and a few grinds of black pepper in a medium bowl. Fold
                  in the shrimp until combined. Set aside.
                </p>
                <p>
                  2. Add the chorizo to a 6-quart rice cooker, followed by the
                  red pepper and then the onion. Top with the rice, red pepper
                  flakes, 1/2 teaspoon salt and a few grinds of black pepper.
                  Pour in 3 cups of water, then place the shrimp on top, making
                  sure all the garlicky oil from the bowl gets into the cooker.
                  Put the lid on the rice cooker and cook according to the
                  manufacturer's instructions. (Depending on your rice cooker,
                  this should take 30 to 35 minutes. If your rice cooker has not
                  turned off after 30 minutes, remove the shrimp, place the lid
                  back on the rice cooker and continue cooking until the machine
                  indicates the cycle is complete.)
                </p>
                <p>
                  3. Use tongs to remove the shrimp to a plate. Fold the parsley
                  and lemon juice into the rice mixture, making sure to mix up
                  the ingredients from the bottom of the pot, until everything
                  is well combined. Spoon the rice into bowls, top with the
                  shrimp, sprinkle with some parsley and serve with a squeeze of
                  lemon, if desired.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="1">
          <Accordion.Header>Speedy Singapore Noodles</Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe2} alt="recipe1" />
                <p>
                  Ingredients: 2 x 85g pkts chicken flavoured instant noodles
                  1/4 cup peanut oil 2 eggs, lightly beaten 4 long green
                  shallots, plus extra to garnish, cut diagonally 1 red
                  capsicum, thinly sliced 4 garlic cloves, very finely chopped 8
                  green prawns, peeled (tails intact), deveined 2 tsp mild curry
                  powder 1 tsp caster sugar
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Place noodles in a heatproof bowl (reserving flavour
                  sachets) and pour over enough boiling water to cover. Set
                  aside.
                </p>
                <p>
                  2. Heat 1 tbs oil in a wok or large frypan over high heat. Add
                  the egg, swirling to cover the base of the wok. Cook for 30
                  seconds or until just firm. Roll into an omelette and transfer
                  to a board. Thinly slice. Heat remaining 2 tbs oil in wok,
                  then add the shallot and capsicum and stir-fry for 2 minutes
                  or until shallot has softened. Add garlic and stir-fry for 30
                  seconds or until fragrant. Add the prawns and stir-fry for 2
                  minutes or until just starting to turn pink in colour. Add the
                  curry powder and sugar and stir-fry for 30 seconds or until
                  fragrant. Add one sachet of noodle seasoning, discarding
                  remaining sachet. Stir-fry to combine.
                </p>
                <p>
                  3. Drain noodles and add to wok with soy sauce. Stir-fry until
                  heated through. Serve noodles topped with snow peas and
                  omelette.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="2">
          <Accordion.Header>Pork, pepper and rice noodle soup</Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe3} alt="recipe1" />
                <p>
                  Ingredients: 4 ounces shiitake mushrooms, stems removed,
                  thinly sliced 2 medium carrots (about 4 ounces), chopped 1 red
                  bell pepper (about 7 ounces), finely chopped Kosher salt and
                  freshly ground black pepper 2 cloves garlic, minced One 1-inch
                  piece fresh ginger, minced (about 1 tablespoon) 3 scallions,
                  thinly sliced, white and green parts separated 1 pound ground
                  pork 8 cups low-sodium chicken broth 6 ounces flat rice
                  noodles
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Heat the olive oil in a large heavy-bottomed pot over
                  medium-high heat until shimmering. Add the mushrooms, carrots,
                  bell pepper, 1 teaspoon salt and a few grinds of pepper and
                  cook, stirring occasionally, until the vegetables are
                  softened, 4 to 5 minutes. Add the garlic, ginger and scallion
                  whites and cook, stirring, until softened, 2 to 3 minutes. Add
                  the pork, 1 teaspoon salt and a few grinds of pepper and cook,
                  breaking up the pork with a spoon and stirring occasionally,
                  until no longer pink, 5 to 6 minutes.
                </p>
                <p>
                  2. Pour in the chicken broth and bring to a boil. Add the
                  noodles and cabbage and cook until the noodles are tender and
                  cooked through and the cabbage is tender but still holds a bit
                  of crunch, about 6 minutes. Stir in the soy sauce and vinegar
                  to combine. Season with salt and pepper.
                </p>
                <p>
                  3. Ladle the soup into bowls, sprinkle with the scallion
                  greens and top with some sesame seeds and sriracha if desired.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="3">
          <Accordion.Header>
            Pan-Seared Salmon with Kale and Apple Salad
          </Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe4} alt="recipe1" />
                <p>
                  Ingredients: Four 5-ounce center-cut salmon fillets (about
                  1-inch thick) 3 tablespoons fresh lemon juice 3 tablespoons
                  olive oil Kosher salt 1 bunch kale, ribs removed, leaves very
                  thinly sliced (about 6 cups) 1/4 cup dates 1 Honeycrisp apple
                  1/4 cup finely grated pecorino 3 tablespoons toasted slivered
                  almonds Freshly ground black pepper 4 whole wheat dinner rolls
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Bring the salmon to room temperature 10 minutes before
                  cooking.
                </p>
                <p>
                  2. Meanwhile, whisk together the lemon juice, 2 tablespoons of
                  the olive oil and 1/4 teaspoon salt in a large bowl. Add the
                  kale, toss to coat and let stand 10 minutes.
                </p>
                <p>
                  3. While the kale stands, cut the dates into thin slivers and
                  the apple into matchsticks. Add the dates, apples, cheese and
                  almonds to the kale. Season with pepper, toss well and set
                  aside.{" "}
                </p>
                <p>
                  4. Sprinkle the salmon all over with 1/2 teaspoon salt and
                  some pepper. Heat the remaining 1 tablespoon oil in a large
                  nonstick skillet over medium-low heat. Raise the heat to
                  medium-high. Place the salmon, skin-side up in the pan. Cook
                  until golden brown on one side, about 4 minutes. Turn the fish
                  over with a spatula, and cook until it feels firm to the
                  touch, about 3 minutes more.{" "}
                </p>
                <p>
                  5. Divide the salmon, salad and rolls evenly among four
                  plates.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="4">
          <Accordion.Header>Saag paneer</Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe5} alt="recipe1" />
                <p>
                  Ingredients: 2 large bunches (about 500g) English spinach,
                  trimmed, washed well 1 tsp garam masala 1/2 tsp cumin seeds
                  1/2 tsp coriander seeds 3 garlic cloves, crushed 5cm piece
                  (25g) ginger, peeled, finely chopped 2 tbs ghee 2 Asian (red)
                  eschalots, finely chopped (substitute 1 small red onion) 2
                  ripe tomatoes, finely chopped
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Blanch spinach leaves in a large saucepan of boiling water
                  for 30 seconds, or until just tender. Drain and place in iced
                  water to stop cooking. Squeeze out excess water, finely chop
                  and set aside.
                </p>
                <p>
                  2. Toast garam masala, cumin seeds and coriander seeds in a
                  small dry frypan over medium heat for 2 minutes, stirring
                  often, until fragrant. Remove from heat.
                </p>
                <p>
                  3. Place garlic, ginger and 1 tsp water in a mortar and
                  pestle, and grind to smooth paste. Add the toasted spices and
                  grind until smooth.
                </p>
                <p>
                  4. Place the ghee in a deep frypan over low heat. Add eschalot
                  and cook for 5-6 minutes until golden. Increase heat to
                  medium, add spice paste and cook for 1-2 minutes until
                  fragrant. Add tomato and bring to a simmer, then add spinach
                  and cook until any liquid has evaporated. Stir in the coconut
                  cream and cook for 2-3 minutes until warmed through.
                </p>
                <p>
                  5. Season to taste, then add paneer and cook, gently folding
                  through, until just warmed through.
                </p>
                <p>
                  6. Spoon into serving bowls and top with sliced chilli and
                  coriander leaves. Serve with lemon wedges.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="5">
          <Accordion.Header>
            Sesame-crusted tuna with green tea noodle salad
          </Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe1} alt="recipe1" />
                <p>
                  Ingredients: 6 ounces fully-cooked chorizo, casings removed,
                  chopped 1 red bell pepper, finely chopped 1 small onion,
                  thinly sliced 2 cups long-grain rice
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Whisk the olive oil, sherry, paprika, garlic, 1/2 teaspoon
                  salt and a few grinds of black pepper in a medium bowl. Fold
                  in the shrimp until combined. Set aside.
                </p>
                <p>
                  2. Add the chorizo to a 6-quart rice cooker, followed by the
                  red pepper and then the onion. Top with the rice, red pepper
                  flakes, 1/2 teaspoon salt and a few grinds of black pepper.
                  Pour in 3 cups of water, then place the shrimp on top, making
                  sure all the garlicky oil from the bowl gets into the cooker.
                  Put the lid on the rice cooker and cook according to the
                  manufacturer's instructions. (Depending on your rice cooker,
                  this should take 30 to 35 minutes. If your rice cooker has not
                  turned off after 30 minutes, remove the shrimp, place the lid
                  back on the rice cooker and continue cooking until the machine
                  indicates the cycle is complete.)
                </p>
                <p>
                  3. Use tongs to remove the shrimp to a plate. Fold the parsley
                  and lemon juice into the rice mixture, making sure to mix up
                  the ingredients from the bottom of the pot, until everything
                  is well combined. Spoon the rice into bowls, top with the
                  shrimp, sprinkle with some parsley and serve with a squeeze of
                  lemon, if desired.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
        <Accordion.Item eventKey="6">
          <Accordion.Header>Recipe #7</Accordion.Header>
          <Accordion.Body>
            <div className="recipe-body">
              <div className="group">
                <img src={Recipe1} alt="recipe1" />
                <p>
                  Ingredients: 6 ounces fully-cooked chorizo, casings removed,
                  chopped 1 red bell pepper, finely chopped 1 small onion,
                  thinly sliced 2 cups long-grain rice
                </p>
              </div>
              <div className="text">
                <h4>Directions:</h4>
                <p>
                  1. Whisk the olive oil, sherry, paprika, garlic, 1/2 teaspoon
                  salt and a few grinds of black pepper in a medium bowl. Fold
                  in the shrimp until combined. Set aside.
                </p>
                <p>
                  2. Add the chorizo to a 6-quart rice cooker, followed by the
                  red pepper and then the onion. Top with the rice, red pepper
                  flakes, 1/2 teaspoon salt and a few grinds of black pepper.
                  Pour in 3 cups of water, then place the shrimp on top, making
                  sure all the garlicky oil from the bowl gets into the cooker.
                  Put the lid on the rice cooker and cook according to the
                  manufacturer's instructions. (Depending on your rice cooker,
                  this should take 30 to 35 minutes. If your rice cooker has not
                  turned off after 30 minutes, remove the shrimp, place the lid
                  back on the rice cooker and continue cooking until the machine
                  indicates the cycle is complete.)
                </p>
                <p>
                  3. Use tongs to remove the shrimp to a plate. Fold the parsley
                  and lemon juice into the rice mixture, making sure to mix up
                  the ingredients from the bottom of the pot, until everything
                  is well combined. Spoon the rice into bowls, top with the
                  shrimp, sprinkle with some parsley and serve with a squeeze of
                  lemon, if desired.
                </p>
              </div>
            </div>
          </Accordion.Body>
        </Accordion.Item>
      </Accordion>
    </div>
  );
}

export default function Homepage() {
  return (
    <div className="Recipes">
      <Header />
      <Body />
      <Footer />
    </div>
  );
}
