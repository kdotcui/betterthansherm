import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Recipe1 from "./images/recipe1.png";
import Recipe2 from "./images/recipe2.png";
import Recipe3 from "./images/recipe3.png";
import Recipe4 from "./images/recipe4.png";
import Recipe5 from "./images/recipe5.png";
import React from "react";

/**
 * renders the homepage component.
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  return (
    <div classname="recipes">
      <header />
      <body />
      <footer />
    </div>
  );
}

export default App;
