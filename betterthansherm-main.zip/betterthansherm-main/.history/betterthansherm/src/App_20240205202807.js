import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import { Home } from "./components/Home";
import {
  Recipe1,
  Recipe2,
  Recip3,
  Recipe4,
  Recipe5,
  Recipe6,
  Recipe7,
} from "./components/recipes";
import { Routes, Route } from "react-router-dom";
/**
 * renders the homepage component.
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recipe1" element={<About />} />
        <Route path="/recipe2" element={<Contact />} />
        <Route path="/recipe3" element={<Recipes />} />
        <Route path="/recipe4" element={<Recipe />} />
        <Route path="/recipe5" element={<Recipe />} />
        <Route path="/recipe6" element={<Recipe />} />
        <Route path="/recipe7" element={<Recipe />} />
      </Routes>
    </div>
  );
}

export default App;
