import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import { Routes, Route } from "react-router-dom";
/**
 * renders the homepage component.
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  return (
    <div classname="recipes">
      <header />
      <body />
      <footer />
    </div>
  );
}

export default App;
