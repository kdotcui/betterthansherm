import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import { Home } from "./components/Home";
import {
  Recipe1,
} from "./components/recipes/Recipe1";
import { Recipe2 } from "./components/recipes/Recipe2";
import { Recipe3 } from "./components/recipes/Recipe3";
import { Recipe4 } from "./components/recipes/Recipe4";
import { Recipe5 } from "./components/recipes/Recipe5";
import { Recipe6 } from "./components/recipes/Recipe6";
import { Recipe7 } from "./components/recipes/Recipe7

import { Routes, Route } from "react-router-dom";
/**
 * renders the homepage component.
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recipe1" element={<Recipe1 />} />
        <Route path="/recipe2" element={<Recipe2 />} />
        <Route path="/recipe3" element={<Recipe3 />} />
        <Route path="/recipe4" element={<Recipe4 />} />
        <Route path="/recipe5" element={<Recipe5 />} />
        <Route path="/recipe6" element={<Recipe6 />} />
        <Route path="/recipe7" element={<Recipe7 />} />
      </Routes>
    </div>
  );
}

export default App;
