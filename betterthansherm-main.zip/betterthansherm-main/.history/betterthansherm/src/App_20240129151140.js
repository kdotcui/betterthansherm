import "./App.css";

function Header() {
  return (
    <div className="Header">
      <h1>Header</h1>
    </div>
  );
}

function Footer() {
  return (
    <div className="Footer">
      <h1>Footer</h1>
    </div>
  );
}

export default function Homepage() {
  return (
    <div className="Recipes">
      <h1>Recipes</h1>
    </div>
  );
}
