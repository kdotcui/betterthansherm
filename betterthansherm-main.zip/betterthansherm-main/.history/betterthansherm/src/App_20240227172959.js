import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import React from "react";
import Home from "./components/Home";
import Recipe1 from "./components/recipes/Recipe1";
import Recipe2 from "./components/recipes/Recipe2";
import Recipe3 from "./components/recipes/Recipe3";
import Recipe4 from "./components/recipes/Recipe4";
import Recipe5 from "./components/recipes/Recipe5";
import Recipe6 from "./components/recipes/Recipe6";
import Recipe7 from "./components/recipes/Recipe7";
import Header from "./components/Header";
import Footer from "./components/Footer";
import NavigationBar from "./components/NavigationBar";
import OurTeam from "./components/OurTeam";
import GroceryList from "./components/GroceryList";
import { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Recipe1CookingMode from "./components/cookingMode/Recipe1CookingMode";
import Recipe2CookingMode from "./components/cookingMode/Recipe2CookingMode";
import Recipe3CookingMode from "./components/cookingMode/Recipe3CookingMode";
import Recipe4CookingMode from "./components/cookingMode/Recipe4CookingMode";
import Recipe5CookingMode from "./components/cookingMode/Recipe5CookingMode";
import Recipe6CookingMode from "./components/cookingMode/Recipe6CookingMode";
import Recipe7CookingMode from "./components/cookingMode/Recipe7CookingMode";

/**
 * Renders the Skeleton(header,navbar,footer) of the Website page
 * and includes Routing to different pages
 *
 * @returns {jsx.element} the rendered homepage component.
 */
function App() {
  const [items, setItems] = useState([]);
  return (
    <div>
      <Header />
      <NavigationBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recipe1" element={<Recipe1 />} />
        <Route path="/recipe2" element={<Recipe2 />} />
        <Route path="/recipe3" element={<Recipe3 />} />
        <Route path="/recipe4" element={<Recipe4 />} />
        <Route path="/recipe5" element={<Recipe5 />} />
        <Route path="/recipe6" element={<Recipe6 />} />
        <Route path="/recipe7" element={<Recipe7 />} />
        <Route path="/ourteam" element={<OurTeam />} />
        <Route path="/recipe1cookingmode" element={<Recipe1CookingMode />} />
        <Route path="/recipe2cookingmode" element={<Recipe2CookingMode />} />
        <Route path="/recipe3cookingmode" element={<Recipe3CookingMode />} />
        <Route path="/recipe4cookingmode" element={<Recipe4CookingMode />} />
        <Route path="/recipe5cookingmode" element={<Recipe5CookingMode />} />
        <Route path="/recipe6cookingmode" element={<Recipe6CookingMode />} />
        <Route path="/recipe7cookingmode" element={<Recipe7CookingMode />} />
        <Route
          path="/groceries"
          element={<GroceryList items={items} setItems={setItems} />}
        />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
